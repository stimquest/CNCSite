"use client";
import React, { useState, useRef, useEffect } from 'react';
import dynamic from 'next/dynamic';
import {
    Trees, Bird, Waves, Map as MapIcon,
    Compass, Wind, Info, Heart,
    ArrowRight, Anchor, Navigation,
    Binoculars, Camera, Shield, Eye,
    Sparkles, ChevronRight, ChevronLeft, AlertCircle, Package, Trophy,
    Ruler, Hammer, ShieldAlert
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import Link from 'next/link';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import type { ObservationPoint } from '../../../components/NatureMap';

// Register GSAP (Safe for client-side)
if (typeof window !== 'undefined') {
    gsap.registerPlugin(ScrollTrigger);
}

// Import dynamique de la carte pour éviter les erreurs SSR de Leaflet
const NatureMap = dynamic(() => import('../../../components/NatureMap'), {
    ssr: false,
    loading: () => <div className="w-full h-full bg-slate-100 animate-pulse flex items-center justify-center rounded-[3.5rem]">
        <MapIcon className="text-slate-300 animate-bounce" size={48} />
    </div>
});

// --- DATA: OBSERVATIONS (Sync avec NatureMap) ---
const OBSERVATIONS: ObservationPoint[] = [
    {
        id: 'phoques',
        title: 'Colonie de Phoques',
        type: 'Faune',
        icon: <Binoculars size={20} className="text-turquoise" />,
        desc: "Une colonie de phoques veau-marin réside au cœur du havre. Ils sont particulièrement visibles à marée basse sur les bancs de sable.",
        tip: "L'observation doit se faire à plus de 300m pour ne pas perturber leur repos. Utilisez des jumelles !",
        position: [49.021, -1.564],
        images: [
            "https://images.unsplash.com/photo-1547035160-2647c093a778?q=80&w=800",
            "https://images.unsplash.com/photo-1621508202501-9f9392211462?q=80&w=800",
            "https://images.unsplash.com/photo-1590009628045-81498b9a9d70?q=80&w=800"
        ]
    },
    {
        id: 'phare',
        title: 'Phare d\'Agon',
        type: 'Patrimoine',
        icon: <Anchor size={20} className="text-abysse" />,
        desc: "Sentinelle emblématique marquant l'entrée du havre. Il guide les navigateurs depuis 1856.",
        tip: "Le coucher de sunset depuis le phare offre une vue imprenable sur l'archipel des Écréhou.",
        position: [49.0272, -1.5748],
        images: [
            "https://images.unsplash.com/photo-1505118380757-91f5f5632de0?q=80&w=800"
        ]
    },
    {
        id: 'pres-sales',
        title: 'Les Prés-Salés',
        type: 'Flore',
        icon: <Trees size={20} className="text-green-600" />,
        desc: "Écosystème rare où pousse la salicorne et le lilas de mer. Recouvert uniquement lors des grandes marées.",
        tip: "C'est ici que l'on récolte la célèbre salicorne de Coutainville en début d'été.",
        position: [49.035, -1.550],
        images: [
            "https://images.unsplash.com/photo-1501785888041-af3ef285b470?q=80&w=800",
            "https://images.unsplash.com/photo-1544198365-f5d60b6d8190?q=80&w=800"
        ]
    },
    {
        id: 'oiseaux',
        title: 'Zone Ornithologique',
        type: 'Faune',
        icon: <Bird size={20} className="text-orange-500" />,
        desc: "Escale majeure pour les oiseaux migrateurs comme la Bernache Cravant ou le Tadorne de Belon.",
        tip: "Le calme est de rigueur pour observer les limicoles fouillant la vase.",
        position: [49.030, -1.570],
        // Pas d'images ici pour tester le cas sans photo
    }
];

// --- DATA: HABITANTS (Biodiversité) ---
const HABITANTS = [
    {
        name: "Le Phoque Veau-Marin",
        scientificName: "Phoca vitulina",
        image: "https://images.unsplash.com/photo-1547035160-2647c093a778?q=80&w=800",
        tags: ["★ Espèce Protégée", "• Bancs de sable"],
        tagColor: "text-turquoise",
        desc: "Emblème local du havre. Il ne faut jamais tenter de les approcher directement, surtout lorsqu'ils se reposent sur les bancs de sable à marée basse. S'ils lèvent la tête ou fuient à l'eau, c'est que vous avez franchi leur zone de confort (distance minimale conseillée : 300m)."
    },
    {
        name: "La Salicorne",
        scientificName: "Salicornia europaea",
        image: "https://images.unsplash.com/photo-1501785888041-af3ef285b470?q=80&w=800",
        tags: ["● Vasières (Schorre)"],
        tagColor: "text-green-400",
        desc: "Une plante halophile emblématique qui croque sous la dent. Elle joue un rôle écologique majeur."
    },
    {
        name: "L'Huitrier Pie",
        scientificName: "Haematopus ostralegus",
        image: "https://images.unsplash.com/photo-1540946485063-a40da27545f8?q=80&w=800",
        tags: ["● Mollusques (Coques)"],
        tagColor: "text-orange-400",
        desc: "Un limicole bruyant et agile, reconnaissable à son plumage noir et blanc et son long bec rouge orangé. Son bec est un outil de précision incroyable pour ouvrir les coquillages les plus résistants. Il nidifie souvent à même le sol dans les zones de galets, soyez vigilants au printemps !"
    },
    {
        name: "Le Chardon Bleu",
        scientificName: "Eryngium maritimum",
        image: "https://images.unsplash.com/photo-1508603612713-1cf55798934b?q=80&w=800",
        tags: ["★ Espèce Protégée", "• Dunes"],
        tagColor: "text-blue-400",
        desc: "Véritable joyau des dunes mobiles, cette plante aux feuilles coriaces et épineuses protège le sable de l'érosion éolienne. Son bleu métallique est unique sur le littoral."
    },
    {
        name: "Le Tadorne de Belon",
        scientificName: "Tadorna tadorna",
        image: "https://images.unsplash.com/photo-1555624485-6136be9f67a2?q=80&w=800",
        tags: ["• Zones Humides"],
        tagColor: "text-orange-400",
        desc: "Cet élégant canard bicolore niche souvent dans les terriers de lapins. Un spectacle magnifique."
    },
    {
        name: "L'Oyat",
        scientificName: "Ammophila arenaria",
        image: "https://images.unsplash.com/photo-1506462945847-ac8ea1449469?q=80&w=800",
        tags: ["● Fixateur de dune"],
        tagColor: "text-yellow-400",
        desc: "La plante architecte par excellence. Ses racines peuvent s'enfoncer à plusieurs mètres de profondeur, créant un réseau dense qui retient le sable. Sans elle, la pointe d'Agon ne serait qu'un banc de sable mouvant. Tragiquement sensible au piétinement répété."
    },
    {
        name: "Le Grand Gravelot",
        scientificName: "Charadrius hiaticula",
        image: "https://images.unsplash.com/photo-1552728089-57bdde30eba3?q=80&w=800",
        tags: ["★ Vulnérable", "• Haut de plage"],
        tagColor: "text-red-400",
        desc: "Petit oiseau discret qui pond ses œufs au milieu des galets et des débris de mer. Le mimétisme est tel qu'il est presque impossible de voir le nid avant de marcher dessus."
    }
];

export const NaturePage: React.FC = () => {
    const [activePoint, setActivePoint] = useState<ObservationPoint | null>(null);
    const [currentSlide, setCurrentSlide] = useState(0);
    const estranRef = useRef<HTMLDivElement>(null);
    const biodivRef = useRef<HTMLDivElement>(null);
    const exploreRef = useRef<HTMLElement>(null);
    const exploreWrapperRef = useRef<HTMLDivElement>(null);

    // Reset slide when point changes
    React.useEffect(() => {
        setCurrentSlide(0);
    }, [activePoint?.id]);

    useEffect(() => {
        const ctx = gsap.context(() => {
            // General Fade In for Sections
            const sections = gsap.utils.toArray<HTMLElement>(".educational-section");
            sections.forEach(section => {
                gsap.from(section.children, {
                    scrollTrigger: {
                        trigger: section,
                        start: "top 85%",
                    },
                    y: 30,
                    opacity: 0,
                    duration: 0.8,
                    stagger: 0.1,
                    ease: "power3.out"
                });
            });

            // Specific Grid Animation for Biodiv
            const bioCards = gsap.utils.toArray<HTMLElement>(biodivRef.current?.querySelectorAll(".bio-card") || []);
            bioCards.forEach((card, idx) => {
                gsap.from(card, {
                    scrollTrigger: {
                        trigger: card,
                        start: "top 90%",
                        toggleActions: 'play none none reverse'
                    },
                    y: 40,
                    opacity: 0,
                    duration: 0.8,
                    ease: "power3.out"
                });
            });



        });
        return () => ctx.revert();
    }, []);

    return (
        <div className="w-full font-sans bg-white pb-24">
            {/* 1. HERO SECTION */}
            <section className="relative h-[90vh] flex items-center justify-center overflow-hidden">
                <div className="absolute inset-0">
                    <img
                        src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=2500"
                        className="w-full h-full object-cover"
                        alt="Pointe d'Agon"
                    />
                    <div className="absolute inset-0 bg-linear-to-b from-abysse/30 via-transparent to-white"></div>
                </div>

                <div className="relative z-10 text-center px-4 max-w-5xl mx-auto mt-20">
                    <motion.div
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 1 }}
                    >
                        <span className="bg-white/10 backdrop-blur-md text-white px-6 py-2 rounded-full text-xs font-black uppercase tracking-[0.25em] border border-white/20 mb-8 inline-block shadow-2xl">
                            Espace Naturel Protégé
                        </span>
                        <h1 className="text-6xl md:text-8xl text-white drop-shadow-2xl mb-8 leading-[0.85]">
                            La Pointe d'Agon
                        </h1>
                        <p className="text-white/80 text-lg md:text-xl font-medium max-w-2xl mx-auto leading-relaxed drop-shadow-lg">
                            Là où la terre s'efface devant la mer. Un sanctuaire de dunes et d'estuaire, sauvage et préservé.
                        </p>
                    </motion.div>
                </div>

                <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
                    <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center p-1">
                        <div className="w-1 h-2 bg-white rounded-full"></div>
                    </div>
                </div>
            </section>

            {/* 2. LE PHÉNOMÈNE DES MARÉES (Educational - GSAP Pinned) */}
            {/* 2. L'ESTRAN : COMPRENDRE LES MARÉES */}
            {/* 2. L'ESTRAN : COMPRENDRE LES MARÉES */}
            <section className="py-24 bg-white educational-section" ref={estranRef}>
                <div className="container mx-auto px-6 max-w-[1300px]">
                    <div className="flex flex-col md:flex-row gap-16 items-start">
                        {/* Title Column */}
                        <div className="md:w-1/3 sticky top-32">
                            <span className="text-turquoise text-xs font-black uppercase tracking-widest mb-4 block">
                                Phénomène Naturel
                            </span>
                            <h2 className="text-4xl md:text-5xl text-abysse mb-8 leading-[0.9]">
                                La Respiration<br />du Littoral
                            </h2>
                            <p className="text-base text-slate-600 leading-relaxed font-medium mb-10">
                                Coutainville est le théâtre de l'un des plus grands marnages du monde. Comprendre ce mouvement perpétuel est la première étape de l'observation.
                            </p>

                            <div className="bg-slate-50 p-8 rounded-[2rem] border border-slate-100 relative overflow-hidden group">
                                <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                                    <Waves size={80} className="text-abysse" />
                                </div>
                                <span className="text-6xl font-black text-abysse block mb-2">13m</span>
                                <span className="text-xs text-slate-400 uppercase tracking-widest font-bold">Différence de hauteur d'eau max.</span>
                            </div>
                        </div>

                        {/* Content Column (Grid) */}
                        <div className="md:w-2/3 grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="bg-slate-50 p-8 rounded-[2rem] border border-slate-100 md:col-span-2 group hover:bg-white hover:shadow-xl hover:border-slate-200 transition-all duration-500">
                                <div className="flex items-start gap-6">
                                    <div className="w-12 h-12 rounded-2xl bg-white flex items-center justify-center shrink-0 text-abysse shadow-sm border border-slate-100 group-hover:scale-110 transition-transform">
                                        <Waves size={24} />
                                    </div>
                                    <div>
                                        <h3 className="text-xl text-abysse mb-3">Zone Intertidale</h3>
                                        <p className="text-slate-600 leading-relaxed">
                                            Lorsque la mer se retire, elle découvre l'estran sur plusieurs kilomètres. Ce n'est pas un désert, mais une zone de chasse et de nourrissage intense pour la faune. Les "criches" (chenaux de drainage) restent en eau et servent de refuge.
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div className="bg-slate-50 p-8 rounded-[2rem] border border-slate-100 group hover:bg-white hover:shadow-xl hover:border-slate-200 transition-all duration-500">
                                <div className="mb-6 text-abysse w-12 h-12 rounded-2xl bg-white flex items-center justify-center shadow-sm border border-slate-100">
                                    <Package size={24} />
                                </div>
                                <h3 className="text-lg text-abysse mb-3">La Laisse de Mer</h3>
                                <p className="text-sm text-slate-600 leading-relaxed">
                                    Ce cordon d'algues n'est pas "sale". En se décomposant, il nourrit les invertébrés (puces de mer) qui nourrissent eux-mêmes les oiseaux. Il piège aussi le sable et consolide la dune.
                                </p>
                            </div>

                            <div className="bg-slate-50 p-8 rounded-[2rem] border border-slate-100 group hover:bg-white hover:shadow-xl hover:border-slate-200 transition-all duration-500">
                                <div className="mb-6 text-orange-600 w-12 h-12 rounded-2xl bg-white flex items-center justify-center shadow-sm border border-slate-100">
                                    <ShieldAlert size={24} />
                                </div>
                                <h3 className="text-lg text-abysse mb-3">Prudence !</h3>
                                <p className="text-sm text-slate-600 leading-relaxed">
                                    La marée remonte vite. La règle : dès que la mer "étale" (cesse de descendre), on commence à remonter vers la côte.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* 3. BIODIVERSITÉ (Inventaire Naturaliste - GRID, no scroll) */}
            {/* 3. BIODIVERSITÉ (Inventaire Naturaliste - DARK GRID, no scroll) */}
            <section className="py-24 bg-abysse text-white" ref={biodivRef}>
                <div className="container mx-auto px-6 max-w-[1300px]">
                    <div className="flex items-end justify-between mb-16 border-b border-white/10 pb-6">
                        <div>
                            <span className="text-turquoise text-xs font-black uppercase tracking-widest mb-2 block">
                                Inventaire du Vivant
                            </span>
                            <h2 className="text-4xl md:text-6xl">
                                Habitants des Lieux
                            </h2>
                        </div>
                        <div className="hidden md:block text-right">
                            <p className="text-slate-400 text-sm max-w-xs">
                                Une faune riche et fragile qui dépend de la bonne santé du havre.
                            </p>
                        </div>
                    </div>

                    <div className="columns-1 md:columns-2 lg:columns-3 gap-8">
                        {HABITANTS.map((specie, idx) => (
                            <div key={idx} className="bio-card inline-block w-full break-inside-avoid-column mb-8 group cursor-default bg-white/5 border border-white/10 rounded-[3rem] p-4 hover:bg-white/10 transition-all duration-500 hover:border-turquoise/30">
                                <div className={`relative rounded-[2.5rem] overflow-hidden mb-6 bg-white/5 ${idx % 3 === 0 ? 'h-96' : idx % 2 === 0 ? 'h-64' : 'h-80'}`}>
                                    <img
                                        src={specie.image}
                                        className="w-full h-full object-cover grayscale-20 group-hover:grayscale-0 transition-all duration-700 group-hover:scale-110"
                                        alt={specie.name}
                                        loading="lazy"
                                    />
                                    <div className="absolute top-4 left-4 bg-abysse/80 backdrop-blur-md px-3 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wide text-white border border-white/20">
                                        {specie.scientificName}
                                    </div>
                                </div>
                                <div className="px-4 pb-4">
                                    <h3 className="text-2xl text-white mb-2 group-hover:text-turquoise transition-colors">
                                        {specie.name}
                                    </h3>
                                    <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wide mb-4 flex flex-wrap gap-x-4 gap-y-2">
                                        {specie.tags.map((tag, tIdx) => (
                                            <span key={tIdx} className={tIdx === 0 ? specie.tagColor : ""}>
                                                {tag}
                                            </span>
                                        ))}
                                    </div>
                                    <p className="text-sm text-slate-300 leading-relaxed">
                                        {specie.desc}
                                    </p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* 4. PÊCHE À PIED DURABLE (Table/List Layout) */}
            {/* 4. PÊCHE À PIED DURABLE (Glass Style) */}
            <section className="py-24 bg-linear-to-b from-slate-50 to-white border-y border-slate-200">
                <div className="container mx-auto px-6 max-w-[1300px]">
                    <div className="flex items-end gap-6 mb-12">
                        <div className="bg-turquoise/10 p-3 rounded-2xl text-turquoise">
                            <Ruler size={32} />
                        </div>
                        <div>
                            <span className="text-slate-400 font-bold uppercase tracking-widest text-xs mb-1 block">Pratique Responsable</span>
                            <h2 className="text-4xl md:text-5xl text-abysse">
                                La Pêche à Pied
                            </h2>
                        </div>
                    </div>

                    <div className="bg-white rounded-[3rem] shadow-2xl border border-slate-100 overflow-hidden relative">
                        {/* Decorative background element */}
                        <div className="absolute top-0 right-0 w-1/3 h-full bg-linear-to-l from-slate-50 to-transparent z-0"></div>

                        <div className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-slate-100 relative z-10">
                            {/* Item 1 */}
                            <div className="p-10 hover:bg-slate-50/50 transition-colors">
                                <h4 className="text-abysse mb-6 text-lg">Tailles Minimales</h4>
                                <ul className="text-sm text-slate-600 space-y-4 font-medium">
                                    <li className="flex justify-between items-center border-b border-slate-100 pb-2">
                                        <span>Coque</span>
                                        <span className="bg-abysse text-white px-3 py-1 rounded-full text-xs font-bold">3 cm</span>
                                    </li>
                                    <li className="flex justify-between items-center border-b border-slate-100 pb-2">
                                        <span>Palourde</span>
                                        <span className="bg-abysse text-white px-3 py-1 rounded-full text-xs font-bold">4 cm</span>
                                    </li>
                                    <li className="flex justify-between items-center border-b border-slate-100 pb-2">
                                        <span>Huitre</span>
                                        <span className="bg-abysse text-white px-3 py-1 rounded-full text-xs font-bold">5 cm</span>
                                    </li>
                                    <li className="flex justify-between items-center">
                                        <span>Moule</span>
                                        <span className="bg-abysse text-white px-3 py-1 rounded-full text-xs font-bold">4 cm</span>
                                    </li>
                                </ul>
                            </div>

                            {/* Item 2 */}
                            <div className="p-10 hover:bg-slate-50/50 transition-colors">
                                <h4 className="text-abysse mb-6 text-lg">Outils & Gestes</h4>
                                <p className="text-slate-600 leading-relaxed mb-6 font-medium">
                                    Les râteaux sont <span className="text-red-500 font-bold">strictement interdits</span> car ils détruisent l'habitat.
                                </p>
                                <div className="flex gap-4">
                                    <div className="flex flex-col items-center gap-2">
                                        <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center text-green-700">
                                            <Hammer size={20} />
                                        </div>
                                        <span className="text-[10px] font-bold uppercase text-slate-400">Gratte</span>
                                    </div>
                                    <div className="flex flex-col items-center gap-2">
                                        <div className="w-12 h-12 rounded-xl bg-red-100 flex items-center justify-center text-red-700 opacity-50 grayscale">
                                            <div className="relative">
                                                <Package size={20} />
                                                <div className="absolute inset-0 border-t-2 border-red-700 -rotate-45 top-1/2"></div>
                                            </div>
                                        </div>
                                        <span className="text-[10px] font-bold uppercase text-slate-400 line-through">Râteau</span>
                                    </div>
                                </div>
                            </div>

                            {/* Item 3 */}
                            <div className="p-10 bg-linear-to-br from-orange-50 to-white">
                                <div className="flex items-center gap-3 mb-6 text-orange-600">
                                    <ShieldAlert size={28} />
                                    <h4 className="text-orange-800 mb-6 text-lg">Sécurité</h4>
                                </div>
                                <p className="text-slate-700 leading-relaxed font-medium">
                                    La marée remonte "à la vitesse d'un cheval au galop".
                                </p>
                                <div className="mt-6 bg-white p-4 rounded-xl border border-orange-100 shadow-sm text-xs font-bold text-orange-800 flex items-center gap-3">
                                    <span className="text-2xl">⚠</span>
                                    <span>Consultez toujours les horaires de marée le jour même.</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* 5. CARTE (Clean layout) */}
            <section className="py-20 bg-white" id="map">
                <div className="container mx-auto px-6 max-w-[1200px]">
                    <h2 className="text-2xl text-abysse mb-8 flex items-center gap-4">
                        <MapIcon size={24} />
                        Carte des Observations
                    </h2>

                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 h-[600px]">
                        <div className="lg:col-span-8 bg-slate-100 rounded-xl overflow-hidden border border-slate-200 relative z-0">
                            <NatureMap observations={OBSERVATIONS} onSelectPoint={setActivePoint} activePointId={activePoint?.id} />
                        </div>
                        <div className="lg:col-span-4 bg-slate-50 rounded-xl border border-slate-200 p-6 flex flex-col overflow-y-auto">
                            {activePoint ? (
                                <div className="animate-fade-in">
                                    <div className="text-[10px] font-bold uppercase tracking-widest text-turquoise mb-2">{activePoint.type}</div>
                                    <h3 className="text-xl text-abysse mb-4">{activePoint.title}</h3>

                                    {activePoint.images && activePoint.images.length > 0 && (
                                        <div className="rounded-lg overflow-hidden mb-4 aspect-video">
                                            <img src={activePoint.images[0]} className="w-full h-full object-cover" alt={activePoint.title} />
                                        </div>
                                    )}

                                    <p className="text-sm text-slate-600 leading-relaxed mb-6">
                                        {activePoint.desc}
                                    </p>

                                    <div className="bg-white p-4 rounded-lg border border-slate-200 text-xs text-slate-500 italic mt-auto">
                                        <span className="font-bold not-italic text-abysse block mb-1">Le Conseil :</span>
                                        {activePoint.tip}
                                    </div>
                                </div>
                            ) : (
                                <div className="h-full flex flex-col items-center justify-center text-slate-400 text-center">
                                    <Binoculars size={32} className="mb-3 opacity-50" />
                                    <p className="text-sm font-medium">Sélectionnez un point<br />sur la carte</p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </section>

            {/* 6. EXPLORATION FOOTER (Minimalist) */}
            {/* 6. EXPLORATION IMMERSIVE (Vertical Stacking Cards) */}
            <section className="relative bg-abysse">
                {/* Header of the section */}
                <div className="py-24 text-center px-4 relative z-0">
                    <span className="text-turquoise text-sm font-black uppercase tracking-[0.3em] mb-4 block animate-pulse">
                        Passer à l'action
                    </span>
                    <h2 className="text-4xl md:text-6xl text-white mb-6 relative inline-block">
                        Explorer le Havre
                        <span className="absolute -bottom-2 left-0 w-full h-1 bg-turquoise transform -skew-x-12"></span>
                    </h2>
                    <p className="text-slate-400 max-w-xl mx-auto text-lg">
                        Le CNC vous propose une flotte complète pour découvrir la zone.
                    </p>
                </div>

                {/* Card 1: Kayak */}
                <div className="sticky top-0 h-screen flex items-center justify-center overflow-hidden border-t border-white/10 bg-abysse z-10">
                    <div className="absolute inset-0">
                        <img src="https://images.unsplash.com/photo-1541625602330-2277a4c46182?q=80&w=2500" className="w-full h-full object-cover opacity-60 scale-105" alt="Kayak" />
                        <div className="absolute inset-0 bg-linear-to-t from-abysse via-abysse/50 to-transparent"></div>
                    </div>
                    <div className="relative z-10 container mx-auto px-6 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                        <div className="md:order-1">
                            <h3 className="text-7xl md:text-9xl text-white mb-4 opacity-10">01.</h3>
                            <h2 className="text-5xl md:text-7xl text-white mb-6 leading-[0.9]">
                                Canoë<br /><span className="text-turquoise">Kayak</span>
                            </h2>
                            <p className="text-xl text-slate-200 font-medium leading-relaxed mb-8 max-w-md">
                                L'approche furtive par excellence. Glissez sans bruit vers les bancs de sable pour observer les phoques sans les déranger.
                            </p>
                            <ul className="space-y-3 mb-10 text-sm font-bold uppercase tracking-widest text-slate-400">
                                <li className="flex items-center gap-3"><span className="w-2 h-2 rounded-full bg-turquoise"></span>Solo ou Duo</li>
                                <li className="flex items-center gap-3"><span className="w-2 h-2 rounded-full bg-turquoise"></span>Accessible à tous</li>
                                <li className="flex items-center gap-3"><span className="w-2 h-2 rounded-full bg-turquoise"></span>Idéal marée haute</li>
                            </ul>
                            <Link href="/club" className="inline-block px-8 py-4 bg-white text-abysse rounded-full font-black uppercase tracking-widest hover:bg-turquoise hover:text-white transition-all transform hover:scale-105 shadow-xl">
                                Louer un Kayak
                            </Link>
                        </div>
                    </div>
                </div>

                {/* Card 2: Paddle */}
                <div className="sticky top-0 h-screen flex items-center justify-center overflow-hidden border-t border-white/10 bg-abysse z-20">
                    <div className="absolute inset-0">
                        <img src="https://images.unsplash.com/photo-1594767222378-0020163539de?q=80&w=2500" className="w-full h-full object-cover opacity-60 scale-105" alt="Paddle" />
                        <div className="absolute inset-0 bg-linear-to-t from-abysse via-abysse/50 to-transparent"></div>
                    </div>
                    <div className="relative z-10 container mx-auto px-6 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                        <div className="md:order-2 md:text-right">
                            <h3 className="text-7xl md:text-9xl text-white mb-4 opacity-10">02.</h3>
                            <h2 className="text-5xl md:text-7xl text-white mb-6 leading-[0.9]">
                                Stand-Up<br /><span className="text-turquoise">Paddle</span>
                            </h2>
                            <p className="text-xl text-slate-200 font-medium leading-relaxed mb-8 max-w-md ml-auto">
                                Prenez de la hauteur. La position debout offre un angle unique pour voir le fond, les poissons et les herbiers à travers l'eau claire.
                            </p>
                            <ul className="space-y-3 mb-10 text-sm font-bold uppercase tracking-widest text-slate-400 flex flex-col items-end">
                                <li className="flex items-center gap-3">Calme & Zen<span className="w-2 h-2 rounded-full bg-turquoise"></span></li>
                                <li className="flex items-center gap-3">Gainage complet<span className="w-2 h-2 rounded-full bg-turquoise"></span></li>
                                <li className="flex items-center gap-3">Balade côtière<span className="w-2 h-2 rounded-full bg-turquoise"></span></li>
                            </ul>
                            <Link href="/club" className="inline-block px-8 py-4 bg-transparent border-2 border-white text-white rounded-full font-black uppercase tracking-widest hover:bg-white hover:text-abysse transition-all transform hover:scale-105 shadow-xl">
                                Réserver un Paddle
                            </Link>
                        </div>
                    </div>
                </div>

                {/* Card 3: Trimaran */}
                <div className="sticky top-0 h-screen flex items-center justify-center overflow-hidden border-t border-white/10 bg-abysse z-30">
                    <div className="absolute inset-0">
                        <img src="https://images.unsplash.com/photo-1534349762230-e0cadf78f5da?q=80&w=2500" className="w-full h-full object-cover opacity-60 scale-105" alt="Voile" />
                        <div className="absolute inset-0 bg-linear-to-t from-abysse via-abysse/50 to-transparent"></div>
                    </div>
                    <div className="relative z-10 container mx-auto px-6 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                        <div className="md:order-1">
                            <h3 className="text-7xl md:text-9xl text-white mb-4 opacity-10">03.</h3>
                            <h2 className="text-5xl md:text-7xl text-white mb-6 leading-[0.9]">
                                Trimaran<br /><span className="text-turquoise">& Catamaran</span>
                            </h2>
                            <p className="text-xl text-slate-200 font-medium leading-relaxed mb-8 max-w-md">
                                Sensations de vitesse pures. Notre flotte de multicoques modernes vous permet d'explorer la zone large et de filer vers Chausey ou les Écréhou.
                            </p>
                            <ul className="space-y-3 mb-10 text-sm font-bold uppercase tracking-widest text-slate-400">
                                <li className="flex items-center gap-3"><span className="w-2 h-2 rounded-full bg-turquoise"></span>Stages & Location</li>
                                <li className="flex items-center gap-3"><span className="w-2 h-2 rounded-full bg-turquoise"></span>Sensations fortes</li>
                                <li className="flex items-center gap-3"><span className="w-2 h-2 rounded-full bg-turquoise"></span>Navigation sportive</li>
                            </ul>
                            <Link href="/club" className="inline-block px-8 py-4 bg-turquoise text-abysse rounded-full font-black uppercase tracking-widest hover:bg-white transition-all transform hover:scale-105 shadow-xl">
                                Voir la Flotte
                            </Link>
                        </div>
                    </div>
                </div>
            </section>

        </div>
    );
};

export default NaturePage;
