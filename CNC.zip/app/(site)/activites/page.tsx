"use client";

import React, { useState, useMemo } from 'react';
import {
    Anchor,
    Wind,
    Waves,
    ChevronDown,
    ChevronUp,
    CheckCircle2,
    Euro,
    GraduationCap,
    Clock,
    Calendar,
    Info,
    Compass,
    Sparkles,
    Users
} from 'lucide-react';
import { Activity, ActivityCategory } from '../../../types';
import { useContent } from '../../../contexts/ContentContext';
import { motion } from 'framer-motion';

export const ActivitiesPage: React.FC = () => {
    const { weather, activities } = useContent();
    const [activeFilter, setActiveFilter] = useState<ActivityCategory | 'TOUTES'>('TOUTES');
    const [expandedId, setExpandedId] = useState<string | null>(null);

    const filteredActivities = useMemo(() => {
        return activities.filter(a => activeFilter === 'TOUTES' || a.category === activeFilter);
    }, [activeFilter, activities]);

    const toggleExpand = (id: string) => {
        setExpandedId(expandedId === id ? null : id);
    };

    return (
        <div className="min-h-screen bg-slate-50 pb-32">

            {/* 1. HERO HEADER - IMMERSIF */}
            <section className="relative h-[80vh] min-h-[600px] w-full flex items-center justify-center overflow-hidden bg-abysse">
                <div className="absolute inset-0 z-0">
                    <img
                        src="https://images.unsplash.com/photo-1513326738677-b93060cf2c0b?q=80&w=2000"
                        className="w-full h-full object-cover opacity-50 scale-105"
                        alt="Water Activities"
                    />
                    <div className="absolute inset-0 bg-linear-to-b from-abysse/80 via-abysse/40 to-white"></div>
                </div>

                <div className="relative z-10 container mx-auto px-6 max-w-[1400px] mt-20">
                    <div className="flex flex-col items-center text-center">
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="bg-white/10 backdrop-blur-md border border-white/20 px-6 py-2 rounded-full mb-8"
                        >
                            <span className="text-[9px] font-black uppercase tracking-widest text-turquoise flex items-center gap-2">
                                <Compass size={14} /> Saison 2026
                            </span>
                        </motion.div>

                        <motion.h1
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.1 }}
                            className="text-6xl md:text-8xl lg:text-9xl text-white leading-[0.8] mb-12"
                        >
                            Catalogue <br />
                            <span className="text-transparent bg-clip-text bg-linear-to-r from-turquoise to-white">Activités.</span>
                        </motion.h1>

                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.2 }}
                            className="flex flex-wrap justify-center gap-6"
                        >
                            <div className="bg-white rounded-[2rem] p-8 shadow-2xl flex items-center gap-8 border border-slate-100 min-w-[280px]">
                                <div className="size-16 rounded-2xl bg-abysse flex items-center justify-center text-white shadow-lg shrink-0">
                                    <Waves size={32} />
                                </div>
                                <div className="text-left">
                                    <p className="text-[9px] font-black uppercase tracking-[0.2em] text-slate-400 mb-1">Nombre</p>
                                    <p className="text-4xl font-black text-abysse tracking-tighter">15+</p>
                                    <p className="text-[10px] text-slate-400 font-bold mt-1 uppercase">Supports nautiques</p>
                                </div>
                            </div>

                            <div className="bg-white/10 backdrop-blur-xl rounded-[2rem] p-8 border border-white/10 flex items-center gap-8 min-w-[280px]">
                                <div className="size-16 rounded-2xl bg-white/10 flex items-center justify-center text-white shrink-0">
                                    <CheckCircle2 size={32} />
                                </div>
                                <div className="text-left">
                                    <p className="text-[9px] font-black uppercase tracking-[0.2em] text-white/40 mb-1">Niveau</p>
                                    <p className="text-3xl font-black text-white uppercase italic leading-none">98% Satisfaction</p>
                                    <p className="text-[10px] text-white/60 font-bold mt-1 uppercase italic">Avis pratiquants</p>
                                </div>
                            </div>
                        </motion.div>
                    </div>
                </div>
            </section>

            {/* 2. BARRE DE FILTRES (STICKY) */}
            <section className="sticky top-16 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-sm py-4">
                <div className="max-w-[1400px] mx-auto px-6 flex flex-wrap justify-center gap-2 md:gap-4">
                    {['TOUTES', 'Sensations', 'Voile', 'Jeunesse', 'Bien-être', 'Sécurité'].map((cat) => (
                        <button
                            key={cat}
                            onClick={() => setActiveFilter(cat as any)}
                            className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all border ${activeFilter === cat
                                ? 'bg-abysse text-white border-abysse shadow-lg scale-105'
                                : 'bg-white text-slate-400 border-slate-100 hover:border-turquoise hover:text-turquoise hover:bg-slate-50'
                                }`}
                        >
                            {cat}
                        </button>
                    ))}
                </div>
            </section>

            {/* LISTE DES ACTIVITÉS */}
            <section className="max-w-[1400px] mx-auto px-4 md:px-6 py-12 space-y-8">
                {filteredActivities.map((activity) => {
                    const isExpanded = expandedId === activity.id;

                    return (
                        <div
                            key={activity.id}
                            className="bg-white rounded-[2rem] overflow-hidden shadow-sm border border-slate-200 transition-all duration-300 hover:shadow-lg"
                        >
                            {/* TOP PART : MAIN CARD */}
                            <div className="flex flex-col lg:flex-row">

                                {/* IMAGE (35%) */}
                                <div className="relative lg:w-[35%] min-h-[300px] lg:min-h-[380px]">
                                    <img
                                        src={activity.image}
                                        alt={activity.title}
                                        className="absolute inset-0 w-full h-full object-cover"
                                    />
                                    <div className="absolute inset-0 bg-linear-to-t from-abysse/50 to-transparent lg:bg-linear-to-r lg:from-transparent lg:to-black/10"></div>

                                    {/* BADGES */}
                                    <div className="absolute inset-0 pointer-events-none">
                                        {/* AGE BADGE - DISCREET CORNER GLASS (Balanced Contrast) */}
                                        <div className="absolute top-0 left-0">
                                            <div className="bg-abysse/25 backdrop-blur-md text-white px-5 py-4 rounded-br-2xl border-b border-r border-white/20 flex flex-col items-center">
                                                <span className="text-[7px] font-black uppercase tracking-[0.2em] text-white/80 mb-1 leading-none">
                                                    À partir de
                                                </span>
                                                <span className="text-2xl font-black italic tracking-tighter leading-none">
                                                    {activity.minAge} ans
                                                </span>
                                            </div>
                                        </div>

                                        {/* CATEGORY BADGE - TOP RIGHT */}
                                        <div className="absolute top-6 right-6">
                                            <div className="bg-white/10 backdrop-blur-md border border-white/20 text-white px-4 py-2 rounded-full text-[9px] font-black uppercase tracking-widest shadow-sm">
                                                {activity.category}
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* CONTENT (65%) */}
                                <div className="flex-1 p-8 lg:p-10 flex flex-col justify-between">

                                    <div className="flex flex-col lg:flex-row justify-between gap-8">
                                        {/* Text Info */}
                                        <div className="flex-1">
                                            <h2 className="text-2xl md:text-3xl text-abysse mb-3">
                                                {activity.title}
                                            </h2>
                                            <p className="text-turquoise text-xs font-black uppercase tracking-widest mb-6 leading-relaxed">
                                                "{activity.accroche}"
                                            </p>
                                            <p className="text-slate-600 font-medium text-sm leading-loose mb-6 text-justify">
                                                {activity.experience || activity.description}
                                            </p>
                                            {/* Quick Info Line */}
                                            <div className="flex items-center gap-6 text-slate-400 text-xs font-bold uppercase tracking-widest">
                                                <span className="flex items-center gap-2"><Clock size={14} /> {activity.duration}</span>
                                                <span className="flex items-center gap-2"><Calendar size={14} /> Saison 2026</span>
                                            </div>
                                        </div>

                                        {/* Actions Column */}
                                        <div className="flex flex-col gap-3 min-w-[220px] border-t lg:border-t-0 lg:border-l border-slate-100 pt-6 lg:pt-0 lg:pl-8">
                                            {/* SECONDARY ACTIONS: IDENTICAL STYLE (Light) - NOW AT TOP */}
                                            <a href={activity.bookingUrl} target="_blank" className="w-full py-4 bg-slate-50 text-abysse border border-slate-200 rounded-xl text-[10px] font-black uppercase tracking-widest hover:border-turquoise hover:text-turquoise transition-colors flex items-center justify-center gap-2">
                                                <Calendar size={14} /> S'inscrire en Stage
                                            </a>
                                            <a href={activity.bookingUrl} target="_blank" className="w-full py-4 bg-slate-50 text-abysse border border-slate-200 rounded-xl text-[10px] font-black uppercase tracking-widest hover:border-turquoise hover:text-turquoise transition-colors flex items-center justify-center gap-2">
                                                <Wind size={14} /> Réserver Séance
                                            </a>
                                            <a href={activity.bookingUrl} target="_blank" className="w-full py-4 bg-slate-50 text-abysse border border-slate-200 rounded-xl text-[10px] font-black uppercase tracking-widest hover:border-turquoise hover:text-turquoise transition-colors flex items-center justify-center gap-2">
                                                <Anchor size={14} /> Louer le matériel
                                            </a>

                                            <div className="h-px bg-slate-100 my-2"></div>

                                            {/* PRIMARY ACTION: DETAILS (PROMINENT - SITE TURQUOISE) - NOW AT BOTTOM */}
                                            <button
                                                onClick={() => toggleExpand(activity.id)}
                                                className={`w-full py-4 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2 shadow-xl ${isExpanded
                                                    ? 'bg-abysse text-white'
                                                    : 'bg-turquoise text-white hover:bg-abysse shadow-turquoise/20'
                                                    }`}
                                            >
                                                {isExpanded ? 'Masquer les infos' : 'Voir Détails & Tarifs'}
                                                {isExpanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* EXPANDABLE DETAILS PANEL */}
                            <div
                                className={`grid transition-all duration-500 ease-in-out bg-slate-50 ${isExpanded ? 'grid-rows-[1fr] opacity-100 border-t border-slate-100' : 'grid-rows-[0fr] opacity-0'
                                    }`}
                            >
                                <div className="overflow-hidden">
                                    <div className="p-8 lg:p-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">

                                        {/* COL 1: LA FLOTTE */}
                                        <div>
                                            <h4 className="flex items-center gap-3 text-sm text-abysse mb-6">
                                                <Anchor size={18} className="text-turquoise" /> La Flotte
                                            </h4>
                                            <ul className="space-y-3">
                                                <li className="text-xs text-slate-600 font-medium leading-relaxed">
                                                    <span className="block font-bold text-abysse mb-1">• Matériel Récent</span>
                                                    Renouvelé tous les 3 ans pour garantir sécurité et performance.
                                                </li>
                                                <li className="text-xs text-slate-600 font-medium leading-relaxed">
                                                    <span className="block font-bold text-abysse mb-1">• Adapté au niveau</span>
                                                    Du support stable pour l'initiation au modèle sport pour la vitesse.
                                                </li>
                                                <li className="text-xs text-slate-600 font-medium leading-relaxed">
                                                    <span className="block font-bold text-abysse mb-1">• Sécurité</span>
                                                    Bateaux de sécurité toujours sur l'eau et liaison radio.
                                                </li>
                                            </ul>
                                        </div>

                                        {/* COL 2: PÉDAGOGIE */}
                                        <div>
                                            <h4 className="flex items-center gap-3 text-sm text-abysse mb-6">
                                                <GraduationCap size={18} className="text-turquoise" /> Pédagogie
                                            </h4>
                                            <div className="text-xs text-slate-600 font-medium leading-relaxed text-justify">
                                                {activity.pedagogie ? activity.pedagogie : "Une progression individualisée grâce au livret de voile FFV. Nos moniteurs diplômés vous accompagnent vers l'autonomie en validant vos niveaux techniques."}
                                            </div>
                                        </div>

                                        {/* COL 3: TARIFS */}
                                        <div>
                                            <h4 className="flex items-center gap-3 text-sm text-abysse mb-6">
                                                <Euro size={18} className="text-turquoise" /> Tarifs 2026
                                            </h4>
                                            <ul className="space-y-3">
                                                {(activity.prices || []).map((price, idx) => (
                                                    <li key={idx} className="flex justify-between items-center pb-2 border-b border-slate-200/50">
                                                        <span className="text-xs font-bold text-slate-500 uppercase">{price.label}</span>
                                                        <span className="text-sm font-black text-abysse">{price.value}</span>
                                                    </li>
                                                ))}
                                            </ul>
                                            <p className="mt-3 text-[10px] text-slate-400 italic leading-tight">
                                                * Les tarifs stages incluent la licence et l'adhésion temporaire.
                                            </p>
                                        </div>

                                        {/* COL 4: PRATIQUE */}
                                        <div>
                                            <h4 className="flex items-center gap-3 text-sm text-abysse mb-6">
                                                <CheckCircle2 size={18} className="text-turquoise" /> Pratique
                                            </h4>
                                            <ul className="space-y-2">
                                                {(activity.logistique || []).map((item, idx) => (
                                                    <li key={idx} className="flex items-start gap-2">
                                                        <div className="mt-1 size-1.5 rounded-full bg-turquoise shrink-0"></div>
                                                        <span className="text-xs font-medium text-slate-600">{item}</span>
                                                    </li>
                                                ))}
                                            </ul>
                                            {activity.isTideDependent && (
                                                <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-100 flex gap-2">
                                                    <Waves size={16} className="text-blue-500 shrink-0" />
                                                    <p className="text-[10px] font-bold text-blue-800 leading-tight">
                                                        Activité dépendante de la marée. Horaires variables.
                                                    </p>
                                                </div>
                                            )}
                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>
                    );
                })}
            </section>

        </div>
    );
};

export default ActivitiesPage;
