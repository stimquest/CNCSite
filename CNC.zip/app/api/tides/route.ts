import { NextResponse } from 'next/server';
import fs from 'fs/promises';
import { existsSync } from 'fs';
import path from 'path';
import { format } from 'date-fns';

// Configuration API WorldTides
const WORLDTIDES_API_KEY = "0cfc0fea-9de7-43b4-b7cb-a6881c6f8c7e";
const LAT = 49.017;
const LON = -1.55;

/**
 * Fonction interne pour mettre à jour les marées si nécessaire
 * Retourne les données à jour
 */
async function getOrUpdateTidesData(tidesPath: string) {
  let tidesData = { data: [] as any[], updatedAt: 0 };
  let needsFetch = true;

  // 1. Essayer de lire le fichier existant
  if (existsSync(tidesPath)) {
    try {
      const content = await fs.readFile(tidesPath, 'utf-8');
      tidesData = JSON.parse(content);

      // Vérifier la fraîcheur des données
      if (tidesData.data && tidesData.data.length > 0) {
        const latestTimestamp = Math.max(...tidesData.data.map((d: any) => d.timestamp));
        const now = Date.now();
        const remainingHours = (latestTimestamp - now) / (1000 * 60 * 60);

        // Si on a encore plus de 24h de données, on ne touche à rien
        if (remainingHours > 24) {
          needsFetch = false;
        }
      }
    } catch (e) {
      console.error("Erreur lecture tides.json, régénération forcée.");
    }
  }

  // 2. Si besoin de mise à jour, on appelle l'API WorldTides
  if (needsFetch) {
    console.log("🌊 [API] Données marées périmées ou absentes. Mise à jour via WorldTides...");

    try {
      const url = `https://www.worldtides.info/api/v3?heights&extremes&lat=${LAT}&lon=${LON}&key=${WORLDTIDES_API_KEY}&days=7&datum=CD&step=900`;
      const response = await fetch(url);
      const data = await response.json();

      if (data.error) throw new Error(`WorldTides error: ${data.error}`);

      console.log(`💳 [API] Crédits consommés: ${data.credits_used || 'inconnu'}`);

      const tasks = [];
      if (data.heights) {
        for (const h of data.heights) {
          tasks.push({
            timestamp: h.dt * 1000,
            type: "height",
            height: h.height,
          });
        }
      }
      if (data.extremes) {
        for (const e of data.extremes) {
          tasks.push({
            timestamp: e.dt * 1000,
            type: "extreme",
            height: e.height,
            status: e.type.toLowerCase(),
          });
        }
      }

      // Sauvegarde dans le fichier
      tidesData = {
        updatedAt: Date.now(),
        data: tasks
      };

      await fs.mkdir(path.dirname(tidesPath), { recursive: true });
      await fs.writeFile(tidesPath, JSON.stringify(tidesData, null, 2));
      console.log("✅ [API] Tides.json mis à jour avec succès.");

    } catch (error) {
      console.error("❌ [API] Échec mise à jour WorldTides:", error);
      // On retourne les anciennes données si l'API échoue, pour ne pas casser le site
    }
  }

  return tidesData;
}

export async function GET() {
  try {
    const tidesPath = path.join(process.cwd(), 'lib/data/tides.json');
    const coeffPath = path.join(process.cwd(), 'lib/data/marees_2026.json');

    // 1. Récupérer (et potentiellement mettre à jour) les données de marées
    const tidesJson = await getOrUpdateTidesData(tidesPath);

    // 2. Lire les coefficients (statiques)
    let coeffJson = { donnees: [] };
    if (existsSync(coeffPath)) {
      const coeffContent = await fs.readFile(coeffPath, 'utf-8');
      coeffJson = JSON.parse(coeffContent);
    }

    // 3. Trouver le coefficient du jour
    const todayStr = format(new Date(), 'yyyy-MM-dd');
    const todayCoeff = coeffJson.donnees.find((d: any) => d.date === todayStr);

    return NextResponse.json({
      tides: tidesJson.data,
      coefficients: todayCoeff || null
    });
  } catch (error: any) {
    console.error("API Error reading local data:", error);
    return NextResponse.json({ error: "Local data unavailable" }, { status: 500 });
  }
}
