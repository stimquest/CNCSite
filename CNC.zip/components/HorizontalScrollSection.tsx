'use client';

import { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { GraduationCap, ArrowRight, Leaf, LifeBuoy, Users } from 'lucide-react';
import Link from 'next/link';

export default function HorizontalScrollSection() {
    const targetRef = useRef<HTMLDivElement | null>(null);
    const { scrollYProgress } = useScroll({
        target: targetRef,
        offset: ["start start", "end end"]
    });

    const x = useTransform(scrollYProgress, [0, 1], ["0%", "-50%"]);

    return (
        <section ref={targetRef} className="relative h-[300vh] bg-white">
            <div className="sticky top-0 flex h-screen items-center overflow-hidden">
                <motion.div style={{ x }} className="flex gap-16 px-16 will-change-transform">



                    {/* CARD 1 : ACADÉMIE NAUTIQUE */}
                    <Link href="/ecole-voile" className="group relative h-[80vh] w-[85vw] md:w-[60vw] lg:w-[50vw] shrink-0 overflow-hidden rounded-[3rem] bg-slate-50 border border-slate-200 shadow-2xl transition-all hover:scale-[1.02] duration-500">
                        <div className="grid h-full grid-cols-1 grid-rows-2">
                            {/* Image Half */}
                            <div className="relative h-full overflow-hidden">
                                <img src="/images/imgBank/minimousse.jpg" className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700" alt="Académie Nautique" />
                                <div className="absolute inset-0 bg-linear-to-b from-transparent to-slate-50/20" />
                            </div>
                            {/* Text Half */}
                            <div className="flex flex-col justify-center p-12 bg-white relative">
                                <div className="absolute -top-10 right-12 size-20 bg-abysse rounded-2xl flex items-center justify-center text-white shadow-xl rotate-6 group-hover:rotate-12 transition-transform duration-500">
                                    <GraduationCap size={40} />
                                </div>
                                <span className="text-9xl font-black text-slate-100 absolute bottom-4 right-4 select-none -z-10 group-hover:text-turquoise/10 transition-colors">01</span>

                                <h3 className="text-4xl font-black text-abysse uppercase italic tracking-tighter mb-4">Académie<br />Nautique</h3>
                                <p className="text-slate-600 text-lg font-medium leading-relaxed mb-8 border-l-4 border-turquoise pl-6">
                                    L'école de référence. Une pédagogie structurée labellisée "École Française de Voile" dès 4 ans.
                                </p>
                                <span className="inline-flex items-center gap-3 text-abysse font-black uppercase tracking-widest text-xs group-hover:text-turquoise transition-colors">
                                    Programme École <ArrowRight size={16} className="group-hover:translate-x-2 transition-transform" />
                                </span>
                            </div>
                        </div>
                    </Link>

                    {/* CARD 2 : NATURE */}
                    <Link href="/nature" className="group relative h-[80vh] w-[85vw] md:w-[60vw] lg:w-[50vw] shrink-0 overflow-hidden rounded-[3rem] bg-emerald-50 border border-emerald-100 shadow-2xl transition-all hover:scale-[1.02] duration-500">
                        <div className="grid h-full grid-cols-1 grid-rows-2">
                            {/* Image Half */}
                            <div className="relative h-full overflow-hidden">
                                <img src="/images/imgBank/pointAgon.jpg" className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" alt="Pointe d'Agon" />
                            </div>
                            {/* Text Half */}
                            <div className="flex flex-col justify-center p-12 bg-emerald-50 relative">
                                <div className="absolute -top-10 right-12 size-20 bg-emerald-600 rounded-2xl flex items-center justify-center text-white shadow-xl -rotate-3 group-hover:-rotate-12 transition-transform duration-500">
                                    <Leaf size={40} />
                                </div>
                                <span className="text-9xl font-black text-emerald-900/5 absolute bottom-4 right-4 select-none -z-10 group-hover:text-emerald-600/10 transition-colors">02</span>

                                <h3 className="text-4xl font-black text-abysse uppercase italic tracking-tighter mb-4">La Pointe<br /><span className="text-emerald-600">d'Agon</span></h3>
                                <p className="text-emerald-900/80 text-lg font-medium leading-relaxed mb-8 border-l-4 border-emerald-500 pl-6">
                                    Un écosystème unique protégé. Oiseaux migrateurs, phoques gris et biodiversité exceptionnelle.
                                </p>
                                <span className="inline-flex items-center gap-3 text-abysse font-black uppercase tracking-widest text-xs group-hover:text-emerald-600 transition-colors">
                                    Explorer l'écosystème <ArrowRight size={16} className="group-hover:translate-x-2 transition-transform" />
                                </span>
                            </div>
                        </div>
                    </Link>

                    {/* CARD 3 : SAUVETAGE */}
                    <Link href="/ecole-voile" className="group relative h-[80vh] w-[85vw] md:w-[60vw] lg:w-[50vw] shrink-0 overflow-hidden rounded-[3rem] bg-abysse border border-slate-800 shadow-2xl transition-all hover:scale-[1.02] duration-500">
                        <div className="grid h-full grid-cols-1 grid-rows-2">
                            {/* Image Half */}
                            <div className="relative h-full overflow-hidden">
                                <img src="/images/imgBank/Secourisme.jpg" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" alt="Formation Secourisme" />
                                <div className="absolute inset-0 bg-linear-to-t from-abysse via-transparent to-transparent"></div>
                            </div>
                            {/* Text Half */}
                            <div className="flex flex-col justify-center p-12 bg-abysse relative">
                                <div className="absolute -top-10 right-12 size-20 bg-white/10 backdrop-blur-md rounded-2xl flex items-center justify-center text-turquoise shadow-xl rotate-3 group-hover:rotate-12 transition-transform duration-500 border border-white/10">
                                    <LifeBuoy size={40} />
                                </div>
                                <span className="text-9xl font-black text-white/5 absolute bottom-4 right-4 select-none -z-10 group-hover:text-turquoise/10 transition-colors">03</span>

                                <h3 className="text-4xl font-black text-white uppercase italic tracking-tighter mb-4">Formation &<br />Secourisme</h3>
                                <p className="text-slate-300 text-lg font-medium leading-relaxed mb-8 border-l-4 border-turquoise pl-6">
                                    Centre de formation agréé. Devenez un professionnel de la mer : Diplômes d'État, BNSSA, PSE.
                                </p>
                                <span className="inline-flex items-center gap-3 text-white font-black uppercase tracking-widest text-xs group-hover:text-turquoise transition-colors">
                                    Découvrir les cursus <ArrowRight size={16} className="group-hover:translate-x-2 transition-transform" />
                                </span>
                            </div>
                        </div>
                    </Link>

                    {/* CARD 4 : COMMUNAUTÉ */}
                    <Link href="/club" className="group relative h-[80vh] w-[85vw] md:w-[60vw] lg:w-[50vw] shrink-0 overflow-hidden rounded-[3rem] bg-white border border-slate-100 shadow-2xl transition-all hover:scale-[1.02] duration-500">
                        <div className="grid h-full grid-cols-1 grid-rows-2">
                            {/* Image Half */}
                            <div className="relative h-full overflow-hidden">
                                <img src="/images/imgBank/beneTracteur.jpg" className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700" alt="Vie du Club" />
                            </div>
                            {/* Text Half */}
                            <div className="flex flex-col justify-center p-12 bg-white relative">
                                <div className="absolute -top-10 right-12 size-20 bg-slate-50 rounded-2xl flex items-center justify-center text-abysse shadow-xl -rotate-6 group-hover:-rotate-12 transition-transform duration-500 border border-slate-100">
                                    <Users size={40} />
                                </div>
                                <span className="text-9xl font-black text-slate-100 absolute bottom-4 right-4 select-none -z-10 group-hover:text-abysse/10 transition-colors">04</span>

                                <h3 className="text-4xl font-black text-abysse uppercase italic tracking-tighter mb-4">
                                    Plus qu'une école,<br /> <span className="text-transparent bg-clip-text bg-linear-to-r from-abysse to-turquoise">Une Famille.</span>
                                </h3>
                                <p className="text-slate-600 text-lg font-medium leading-relaxed mb-8 border-l-4 border-turquoise pl-6">
                                    Rejoignez une communauté de passionnés. Régates, barbecues, entraide et convivialité toute l'année.
                                </p>
                                <span className="inline-flex items-center gap-3 text-abysse font-black uppercase tracking-widest text-xs group-hover:text-turquoise transition-colors">
                                    Rejoindre le Club <ArrowRight size={16} className="group-hover:translate-x-2 transition-transform" />
                                </span>
                            </div>
                        </div>
                    </Link>

                </motion.div>
            </div>
        </section>
    );
}
