'use client';

import React, { useRef, useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/dist/ScrollTrigger';
import Link from 'next/link';
import { ArrowRight, GraduationCap, Leaf, LifeBuoy, Users } from 'lucide-react';

if (typeof window !== 'undefined') {
    gsap.registerPlugin(ScrollTrigger);
}

const NarrativePillars = () => {
    const sectionRef = useRef<HTMLDivElement>(null);
    const pinRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const ctx = gsap.context(() => {
            const tl = gsap.timeline({
                scrollTrigger: {
                    trigger: sectionRef.current,
                    start: "top top",
                    end: "+=300%", // 4 slides -> 300% scroll distance (100% per transition)
                    scrub: 1,
                    pin: pinRef.current,
                    anticipatePin: 1
                }
            });

            // --- STEP 1 (Initial) is visible by default ---
            // Transition 1 -> 2 (Nature)
            tl.to('.pillar-bg-1', { opacity: 0, duration: 1 }, 0)
                .to('.pillar-bg-2', { opacity: 1, scale: 1.1, duration: 1 }, 0)
                .to('.pillar-content-1', { opacity: 0, y: -50, filter: 'blur(10px)', duration: 0.5 }, 0)
                .to('.pillar-content-2', { opacity: 1, y: 0, filter: 'blur(0px)', duration: 0.5 }, 0.5)
                .to('.nav-dot-1', { backgroundColor: 'rgba(255,255,255,0.2)', scale: 1 }, 0)
                .to('.nav-dot-2', { backgroundColor: '#14F1C8', scale: 1.5 }, 0.5);

            // Transition 2 -> 3 (Sauvetage)
            tl.to('.pillar-bg-2', { opacity: 0, duration: 1 }, 1.5)
                .to('.pillar-bg-3', { opacity: 1, scale: 1.1, duration: 1 }, 1.5)
                .to('.pillar-content-2', { opacity: 0, y: -50, filter: 'blur(10px)', duration: 0.5 }, 1.5)
                .to('.pillar-content-3', { opacity: 1, y: 0, filter: 'blur(0px)', duration: 0.5 }, 2)
                .to('.nav-dot-2', { backgroundColor: 'rgba(255,255,255,0.2)', scale: 1 }, 1.5)
                .to('.nav-dot-3', { backgroundColor: '#14F1C8', scale: 1.5 }, 2);

            // Transition 3 -> 4 (Communauté)
            tl.to('.pillar-bg-3', { opacity: 0, duration: 1 }, 3)
                .to('.pillar-bg-4', { opacity: 1, scale: 1.1, duration: 1 }, 3)
                .to('.pillar-content-3', { opacity: 0, y: -50, filter: 'blur(10px)', duration: 0.5 }, 3)
                .to('.pillar-content-4', { opacity: 1, y: 0, filter: 'blur(0px)', duration: 0.5 }, 3.5)
                .to('.nav-dot-3', { backgroundColor: 'rgba(255,255,255,0.2)', scale: 1 }, 3)
                .to('.nav-dot-4', { backgroundColor: '#14F1C8', scale: 1.5 }, 3.5);

        }, sectionRef);

        return () => ctx.revert();
    }, []);

    return (
        <section ref={sectionRef} className="relative w-full h-[400vh]">
            <div ref={pinRef} className="sticky top-[12.5vh] h-[75vh] w-full overflow-hidden bg-abysse shadow-2xl">

                {/* --- BACKGROUND LAYERS --- */}
                <div className="absolute inset-0 z-0">
                    {/* 1. Académie */}
                    <img src="/images/imgBank/minimousse.jpg" className="pillar-bg-1 absolute inset-0 w-full h-full object-cover opacity-100" alt="Académie Nautique" />
                    {/* 2. Nature */}
                    <img src="/images/imgBank/pointAgon.jpg" className="pillar-bg-2 absolute inset-0 w-full h-full object-cover opacity-0 scale-100" alt="Pointe d'Agon" />
                    {/* 3. Sauvetage */}
                    <img src="/images/imgBank/Secourisme.jpg" className="pillar-bg-3 absolute inset-0 w-full h-full object-cover opacity-0 scale-100" alt="Sauvetage" />
                    {/* 4. Communauté */}
                    <img src="/images/imgBank/beneTracteur.jpg" className="pillar-bg-4 absolute inset-0 w-full h-full object-cover opacity-0 scale-100" alt="Communauté" />

                    {/* Global Overlay for text readability */}
                    <div className="absolute inset-0 bg-linear-to-b from-abysse/80 via-abysse/40 to-abysse/90 z-10"></div>
                </div>

                {/* --- CONTENT LAYERS --- */}
                <div className="relative z-20 w-full h-full flex flex-col items-center justify-center text-center px-6">

                    {/* CONTENT 1: ACADÉMIE */}
                    <div className="pillar-content-1 absolute max-w-4xl">
                        <div className="inline-flex items-center gap-3 border border-white/20 bg-white/10 backdrop-blur-md px-6 py-2 rounded-full mb-8">
                            <GraduationCap className="text-turquoise" size={20} />
                            <span className="text-white font-bold uppercase tracking-widest text-xs">L'École de Voile</span>
                        </div>
                        <h2 className="text-6xl md:text-8xl font-black text-white uppercase italic tracking-tighter mb-8 leading-[0.9]">
                            Académie <br /><span className="text-transparent bg-clip-text bg-linear-to-r from-turquoise to-white">Nautique.</span>
                        </h2>
                        <p className="text-slate-200 text-xl md:text-2xl font-medium leading-relaxed max-w-2xl mx-auto mb-12">
                            Une pédagogie structurée et labellisée, dès 4 ans.
                            De la découverte des embruns à la maîtrise des éléments.
                        </p>
                        <Link href="/ecole-voile" className="inline-flex items-center gap-3 bg-white text-abysse hover:bg-turquoise hover:text-white px-8 py-4 rounded-xl font-black uppercase text-sm tracking-wide transition-all duration-300">
                            Découvrir les Stages <ArrowRight size={18} />
                        </Link>
                    </div>

                    {/* CONTENT 2: NATURE */}
                    <div className="pillar-content-2 absolute max-w-4xl opacity-0 translate-y-12 blur-sm">
                        <div className="inline-flex items-center gap-3 border border-white/20 bg-white/10 backdrop-blur-md px-6 py-2 rounded-full mb-8">
                            <Leaf className="text-emerald-400" size={20} />
                            <span className="text-white font-bold uppercase tracking-widest text-xs">Environnement</span>
                        </div>
                        <h2 className="text-6xl md:text-8xl font-black text-white uppercase italic tracking-tighter mb-8 leading-[0.9]">
                            La Pointe <br /><span className="text-transparent bg-clip-text bg-linear-to-r from-emerald-400 to-white">d'Agon.</span>
                        </h2>
                        <p className="text-slate-200 text-xl md:text-2xl font-medium leading-relaxed max-w-2xl mx-auto mb-12">
                            Naviguez au cœur d'un site classé. Phoques gris, oiseaux migrateurs...
                            Un terrain de jeu sauvage qu'on protège à chaque bord.
                        </p>
                        <Link href="/nature" className="inline-flex items-center gap-3 bg-white text-abysse hover:bg-emerald-500 hover:text-white px-8 py-4 rounded-xl font-black uppercase text-sm tracking-wide transition-all duration-300">
                            Explorer le Site <ArrowRight size={18} />
                        </Link>
                    </div>

                    {/* CONTENT 3: SAUVETAGE */}
                    <div className="pillar-content-3 absolute max-w-4xl opacity-0 translate-y-12 blur-sm">
                        <div className="inline-flex items-center gap-3 border border-white/20 bg-white/10 backdrop-blur-md px-6 py-2 rounded-full mb-8">
                            <LifeBuoy className="text-red-400" size={20} />
                            <span className="text-white font-bold uppercase tracking-widest text-xs">Formation Pro</span>
                        </div>
                        <h2 className="text-6xl md:text-8xl font-black text-white uppercase italic tracking-tighter mb-8 leading-[0.9]">
                            Sauvetage & <br /><span className="text-transparent bg-clip-text bg-linear-to-r from-red-400 to-white">Expertise.</span>
                        </h2>
                        <p className="text-slate-200 text-xl md:text-2xl font-medium leading-relaxed max-w-2xl mx-auto mb-12">
                            Plus qu'un sport, un métier. Centre de formation agréé pour les futurs
                            BNSSA, marins et sauveteurs. L'excellence au service de la sécurité.
                        </p>
                        <Link href="/ecole-voile" className="inline-flex items-center gap-3 bg-white text-abysse hover:bg-red-500 hover:text-white px-8 py-4 rounded-xl font-black uppercase text-sm tracking-wide transition-all duration-300">
                            Nos Formations <ArrowRight size={18} />
                        </Link>
                    </div>

                    {/* CONTENT 4: COMMUNAUTÉ */}
                    <div className="pillar-content-4 absolute max-w-4xl opacity-0 translate-y-12 blur-sm">
                        <div className="inline-flex items-center gap-3 border border-white/20 bg-white/10 backdrop-blur-md px-6 py-2 rounded-full mb-8">
                            <Users className="text-turquoise" size={20} />
                            <span className="text-white font-bold uppercase tracking-widest text-xs">Vie du Club</span>
                        </div>
                        <h2 className="text-6xl md:text-8xl font-black text-white uppercase italic tracking-tighter mb-8 leading-[0.9]">
                            Une Grande <br /><span className="text-transparent bg-clip-text bg-linear-to-r from-turquoise to-white">Famille.</span>
                        </h2>
                        <p className="text-slate-200 text-xl md:text-2xl font-medium leading-relaxed max-w-2xl mx-auto mb-12">
                            Le CNC, c'est avant tout des humains. Bénévoles, régatiers, passionnés...
                            Rejoignez une communauté qui vit au rythme des marées toute l'année.
                        </p>
                        <Link href="/club" className="inline-flex items-center gap-3 bg-white text-abysse hover:bg-turquoise hover:text-white px-8 py-4 rounded-xl font-black uppercase text-sm tracking-wide transition-all duration-300">
                            Rejoindre le Club <ArrowRight size={18} />
                        </Link>
                    </div>

                </div>

                {/* --- SIDE NAVIGATION DOTS --- */}
                <div className="absolute right-8 top-1/2 -translate-y-1/2 z-30 flex flex-col gap-6">
                    <div className="nav-dot-1 w-3 h-3 rounded-full bg-[#14F1C8] scale-150 transition-colors duration-500"></div>
                    <div className="nav-dot-2 w-3 h-3 rounded-full bg-white/20 transition-colors duration-500"></div>
                    <div className="nav-dot-3 w-3 h-3 rounded-full bg-white/20 transition-colors duration-500"></div>
                    <div className="nav-dot-4 w-3 h-3 rounded-full bg-white/20 transition-colors duration-500"></div>
                </div>

                {/* --- SCROLL HINT --- */}
                <div className="absolute bottom-12 left-1/2 -translate-x-1/2 z-30 flex flex-col items-center gap-2">
                    <span className="text-white/40 text-[9px] font-black uppercase tracking-[0.3em]">Scroller</span>
                    <div className="w-px h-12 bg-linear-to-b from-turquoise to-transparent animate-bounce"></div>
                </div>

            </div>
        </section>
    );
};

export default NarrativePillars;
