"use client";

import React, { createContext, useContext, useState, useEffect } from 'react';
import { MOCK_WEATHER, ACTIVITIES, STATUS_MESSAGE, CURRENT_STATUS } from '../constants';
import { Activity, WeatherData, SpotStatus, NewsItem, TeamMember, FleetItem, WeeklyPlanning, PlanningCharAVoile, HomeGallery, MerchItem, OccazItem, InfoMessage, TideData } from '../types';
import { client } from '../lib/sanity';
import { fetchRealtimeWeather } from '../lib/weather';

interface ContentState {
  weather: WeatherData;
  activities: Activity[];
  statusMessage: string;
  spotStatus: SpotStatus;
  news: NewsItem[];
  team: TeamMember[];
  fleet: FleetItem[];
  plannings: WeeklyPlanning[];
  charPlannings: PlanningCharAVoile[];
  homeGallery: HomeGallery | null;
  merchItems: MerchItem[];
  occazItems: OccazItem[];
  infoMessages: InfoMessage[];
  tides: TideData[];
}

interface ContentContextType extends ContentState {
  updateWeather: (data: WeatherData) => void;
  updateActivity: (id: string, data: Partial<Activity>) => void;
  updateStatus: (status: SpotStatus, message: string) => void;
  resetToDefaults: () => void;
  saveToLocal: () => void;
  refreshData: () => Promise<void>;
  fetchFromSanity: () => Promise<void>;
  lastUpdated: number | null;
  isLoading: boolean;
}

const ContentContext = createContext<ContentContextType | undefined>(undefined);

const queries = {
  activities: `*[_type == "activity" && !(_id in path('drafts.**'))] | order(order asc, title asc) {
        id,
        title,
        category,
        description,
        pedagogie,
        experience,
        logistique,
        price,
        "prices": prices[]{ label, value },
        "image": image.asset->url,
        isTideDependent,
        bookingUrl,
        duration,
        minAge,
        accroche,
        planningNote
    }`,
  settings: `*[_type == "siteSettings"][0] {
        spotStatus,
        statusMessage
    }`,
  news: `*[_type == "news"] | order(publishedAt desc) {
        _id,
        title,
        category,
        "date": publishedAt,
        publishedAt
    }`,
  team: `*[_type == "teamMember"] {
        name,
        role,
        category,
        diplome,
        "image": image.asset->url
    }`,
  fleet: `*[_type == "fleetItem"] {
        id,
        name,
        subtitle,
        description,
        "gallery": gallery[].asset->url,
        stats,
        crew
    }`,
  plannings: `*[_type == "weeklyPlanning"] | order(startDate asc) {
        _id,
        title,
        startDate,
        endDate,
        days[] {
            _key,
            name,
            date,
            isRaidDay,
            miniMousses { time, activity, description },
            mousses { time, activity, description },
            initiation,
            perfectionnement
        }
    }`,
  charPlannings: `*[_type == "planningCharAVoile"] | order(startDate asc) {
        _id,
        title,
        startDate,
        endDate,
        weeks[] {
            _key,
            title,
            startDate,
            endDate,
            days[] {
                _key,
                name,
                date,
                sessions[] {
                    _key,
                    time
                }
            }
        }
    }`,
  homeGallery: `*[_type == "homeGallery"][0] {
        title,
        subtitle,
        "images": images[].asset->url
    }`,
  merchItems: `*[_type == "merchItem"] {
        _id,
        name,
        price,
        description,
        category,
        badge,
        "image": image.asset->url
    }`,
  occazItems: `*[_type == "occazItem"] {
        _id,
        name,
        price,
        condition,
        year,
        description,
        "image": image.asset->url
    }`,
  infoMessages: `*[_type == "infoMessage"] | order(publishedAt desc) {
        _id,
        title,
        content,
        category,
        targetGroups,
        publishedAt,
        isPinned,
        externalLink
    }`
};

export const ContentProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [weather, setWeather] = useState<WeatherData>(MOCK_WEATHER);
  const [activities, setActivities] = useState<Activity[]>(ACTIVITIES);
  const [statusMessage, setStatusMessage] = useState<string>(STATUS_MESSAGE);
  const [spotStatus, setSpotStatus] = useState<SpotStatus>(CURRENT_STATUS);
  const [news, setNews] = useState<NewsItem[]>([]);
  const [team, setTeam] = useState<TeamMember[]>([]);
  const [fleet, setFleet] = useState<FleetItem[]>([]);
  const [plannings, setPlannings] = useState<WeeklyPlanning[]>([]);
  const [charPlannings, setCharPlannings] = useState<PlanningCharAVoile[]>([]);
  const [homeGallery, setHomeGallery] = useState<HomeGallery | null>(null);
  const [merchItems, setMerchItems] = useState<MerchItem[]>([]);
  const [occazItems, setOccazItems] = useState<OccazItem[]>([]);
  const [infoMessages, setInfoMessages] = useState<InfoMessage[]>([]);
  const [tides, setTides] = useState<TideData[]>([]);

  const [lastUpdated, setLastUpdated] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const refreshData = async () => {
    setIsLoading(true);

    const weatherPromise = fetchRealtimeWeather()
      .then(async (data) => {
        if (!data) return;

        // Fetch local tides to enrich weather data
        try {
          const tideRes = await fetch('/api/tides');
          const tideData = await tideRes.json();

          let tideInfo = {};

          // 1. Get Coefficient
          if (tideData.coefficients) {
            tideInfo = {
              ...tideInfo,
              coefficient: tideData.coefficients.coef_1 || tideData.coefficients.coef_2 || 0
            };
          }

          // 2. Get High/Low times for today
          if (tideData.tides) {
            setTides(tideData.tides);
            const now = Date.now();
            const todayStr = new Date().toDateString();
            const daysTides = tideData.tides.filter((t: any) =>
              t.type === 'extreme' && new Date(t.timestamp).toDateString() === todayStr
            );

            const nextHigh = daysTides.find((t: any) => t.status === 'high' && t.timestamp > now) || daysTides.find((t: any) => t.status === 'high');
            const nextLow = daysTides.find((t: any) => t.status === 'low' && t.timestamp > now) || daysTides.find((t: any) => t.status === 'low');

            if (nextHigh) {
              tideInfo = {
                ...tideInfo,
                tideHigh: new Date(nextHigh.timestamp).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })
              };
            }
            if (nextLow) {
              tideInfo = {
                ...tideInfo,
                tideLow: new Date(nextLow.timestamp).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })
              };
            }
          }

          setWeather(prev => ({ ...prev, ...data, ...tideInfo }));
        } catch (e) {
          console.error("Error fetching tides for weather context", e);
          setWeather(prev => ({ ...prev, ...data }));
        }
      })
      .catch(() => { }); // Erreur déjà gérée

    const expertWeatherPromise = fetch('/api/weather-expert')
      .then(r => r.json())
      .then(expertData => {
        if (!expertData || expertData.error) return;

        // Extract water temp and calculate dominant wind description
        const waterTemp = expertData.currents?.hourly?.sea_surface_temperature?.[0];

        // Calculate dominant wind from AROME HD minutely data
        const windSpeeds = expertData.weather?.minutely_15?.wind_speed_10m || [];
        const windGusts = expertData.weather?.minutely_15?.wind_gusts_10m || [];
        const windDirs = expertData.weather?.minutely_15?.wind_direction_10m || [];

        // Find index closest to now (AROME 15min)
        const now = new Date();
        const w15 = expertData.weather?.minutely_15;
        const times = w15?.time || [];

        // Find the first index in the future (or current 15m slot)
        let currentIdx = times.findIndex((t: string) => new Date(t) > now);
        // If we are at the end, take the last one, or if checks failed take 0
        if (currentIdx === -1) currentIdx = 0;
        if (currentIdx > 0) currentIdx = currentIdx - 1; // Take the slot properly covering "now"

        if (times[currentIdx]) {
          const currentWind = Math.round(w15.wind_speed_10m[currentIdx]);
          const currentGust = Math.round(w15.wind_gusts_10m[currentIdx]);
          const currentDirDeg = w15.wind_direction_10m[currentIdx];

          // Helper for direction from degrees
          const getDir = (deg: number) => {
            const di = ['N', 'NE', 'E', 'SE', 'S', 'SO', 'O', 'NO'];
            return di[Math.round(deg / 45) % 8];
          };
          const dominantDir = getDir(currentDirDeg);

          // Calculate Trend (Current vs +3h)
          let trend: 'rising' | 'falling' | 'stable' = 'stable';
          const futureIdx = currentIdx + 12; // +3 hours (12 * 15min)
          if (times[futureIdx]) {
            const futureWind = Math.round(w15.wind_speed_10m[futureIdx]);
            if (futureWind > currentWind + 2) trend = 'rising';
            else if (futureWind < currentWind - 2) trend = 'falling';
          }

          setWeather(prev => ({
            ...prev,
            waterTemp: waterTemp ? Math.round(waterTemp) : prev.waterTemp,
            dominantWind: `${dominantDir} ${currentWind}-${currentGust} nds`, // Keeping this string for legacy components if any
            windSpeed: currentWind, // OVERRIDE the OpenMeteo current value with AROME
            windDirection: dominantDir,
            gusts: currentGust,
            windBearing: currentDirDeg,
            trend: trend,
            weatherCode: expertData.weather?.daily?.weather_code?.[0]
          }));
        }
      })
      .catch(e => console.error("Expert weather fetch failed", e));

    const sanityPromise = (async () => {
      try {
        const { projectId } = client.config();
        if (!projectId) return;

        const [
          sanityActivities,
          sanitySettings,
          sanityNews,
          sanityTeam,
          sanityFleet,
          sanityPlannings,
          sanityCharPlannings,
          sanityGallery,
          sanityMerch,
          sanityOccaz,
          sanityInfoMessages
        ] = await Promise.all([
          client.fetch(queries.activities),
          client.fetch(queries.settings),
          client.fetch(queries.news),
          client.fetch(queries.team),
          client.fetch(queries.fleet),
          client.fetch(queries.plannings),
          client.fetch(queries.charPlannings),
          client.fetch(queries.homeGallery),
          client.fetch(queries.merchItems),
          client.fetch(queries.occazItems),
          client.fetch(queries.infoMessages)
        ]);

        if (sanityActivities?.length > 0) setActivities(sanityActivities);
        if (sanitySettings) {
          setSpotStatus(sanitySettings.spotStatus || spotStatus);
          setStatusMessage(sanitySettings.statusMessage || statusMessage);
        }
        if (sanityNews?.length > 0) setNews(sanityNews);
        if (sanityTeam?.length > 0) setTeam(sanityTeam);
        if (sanityFleet?.length > 0) setFleet(sanityFleet);
        if (sanityPlannings?.length > 0) setPlannings(sanityPlannings);
        if (sanityCharPlannings?.length > 0) setCharPlannings(sanityCharPlannings);
        if (sanityGallery) setHomeGallery(sanityGallery);
        if (sanityMerch?.length > 0) setMerchItems(sanityMerch);
        if (sanityOccaz?.length > 0) setOccazItems(sanityOccaz);
        if (sanityInfoMessages?.length > 0) setInfoMessages(sanityInfoMessages);

      } catch (err) {
        console.warn("Sanity indisponible:", err);
      }
    })();

    await Promise.all([weatherPromise, expertWeatherPromise, sanityPromise]);
    setLastUpdated(Date.now());
    setIsLoading(false);
  };

  useEffect(() => {
    refreshData();
  }, []);

  const updateWeather = (data: WeatherData) => setWeather(data);
  const updateActivity = (id: string, data: Partial<Activity>) => {
    setActivities(prev => prev.map(a => a.id === id ? { ...a, ...data } : a));
  };
  const updateStatus = (status: SpotStatus, message: string) => {
    setSpotStatus(status);
    setStatusMessage(message);
  };

  const resetToDefaults = () => {
    if (confirm("Réinitialiser toutes les données ?")) {
      setWeather(MOCK_WEATHER);
      refreshData();
    }
  };

  const saveToLocal = () => {
    const data = { weather, activities, statusMessage, spotStatus, news, team, fleet, plannings, charPlannings, merchItems, occazItems, timestamp: Date.now() };
    localStorage.setItem('CNC_CONTENT_DATA', JSON.stringify(data));
    setLastUpdated(Date.now());
    alert("Données sauvegardées !");
  };

  return (
    <ContentContext.Provider value={{
      weather, activities, statusMessage, spotStatus, news, team, fleet, plannings, charPlannings, homeGallery,
      merchItems, occazItems, infoMessages, tides,
      updateWeather, updateActivity, updateStatus, resetToDefaults,
      saveToLocal, refreshData, fetchFromSanity: refreshData,
      lastUpdated, isLoading
    }}>
      {children}
    </ContentContext.Provider>
  );
};

export const useContent = () => {
  const context = useContext(ContentContext);
  if (!context) throw new Error('useContent must be used within a ContentProvider');
  return context;
};