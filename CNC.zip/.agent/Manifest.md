---
trigger: always_on
---

# Standards de Développement

# Manifeste Technique : Projet Club Nautique (CNC)

## 1. Environnement & OS

- **Système :** Windows 11 (PowerShell).
- **Interdiction :** Ne jamais utiliser de commandes Bash (ls -ld, touch, rm -rf).
- **Commandes autorisées :** Get-ChildItem, New-Item, Remove-Item.
- **Package Manager :** npm.

## 2. Stack Technique Strict

- **Framework :** Next.js 15+ (App Router).
- **Langage :** TypeScript strict.
- **Styles :** Tailwind CSS uniquement. Pas de bibliothèques de composants externes (sauf si explicitement demandé).
- **Icônes :** Lucide-React.
- **Data Fetching :** Server Components (async/await) par défaut.

## 3. Protection du Design (Source of Truth)

- **Référence Visuelle :** Les images et le HTML fournis par l'utilisateur sont la "Vérité Absolue".
- **Méthode de modification :** Avant de modifier un fichier `.tsx` existant, l'agent doit lire le fichier `.agent/rules/design-system.md` (si présent).
- **Composants :** Séparation stricte entre "UI Components" (présentation) et "Page Containers" (logique/data).
- **CSS :** Utiliser des variables dans `globals.css` pour les couleurs nautiques (Marine, Cyan, Sable) extraites des images de référence.

## 4. Stratégie d'intégration CMS

- **Phase 1 :** Mocking. Les composants sont d'abord développés avec des données statiques.
- **Phase 2 :** Schématisation. Création des schémas dans le CMS (ex: Sanity).
- **Phase 3 :** Raccordement. Injection des données via des Wrappers.
- **Interdiction :** Ne jamais injecter de logique de fetch directement dans un composant de design complexe. Utiliser une couche de service (`lib/cms-service.ts`).

## 5. Workflow de Travail (Agentic Loop)

1. **Analyse :** Lire les fichiers et observer le rendu navigateur.
2. **Planification :** Créer un "Artifact" de plan d'action. Attendre validation.
3. **Exécution :** Coder par petits incréments (un composant à la fois).
4. **Vérification :** Utiliser le navigateur intégré pour valider le rendu visuel.
