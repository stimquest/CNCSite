# Documentation : Effet Logo Blur Mask

## 📋 Vue d'ensemble

Le logo du Hero utilise un **effet de masque avec flou** (blur mask). C'est un effet simple et élégant où :

- Le logo SVG sert de **masque** (découpe)
- Un **flou** (blur) est appliqué sur le fond **uniquement dans la forme du logo**
- Un **effet 3D** au survol de la souris ajoute de l'interactivité

---

## 🎨 Comment ça fonctionne ?

### 1. Le Masque SVG

```css
mask-image: url("/images/LogoCNC_W.svg");
```

Cette propriété découpe l'élément selon la forme du logo. Tout ce qui est en dehors du logo devient invisible.

### 2. Le Flou (Backdrop Filter)

```css
backdrop-filter: blur(20px);
```

Cette propriété applique un flou sur **ce qui est derrière** l'élément. Combiné avec le masque, le flou n'apparaît que dans la forme du logo.

### 3. La Teinte Blanche

```css
background: rgba(255, 255, 255, 0.2);
```

Une légère teinte blanche (20% d'opacité) rend le logo visible et lumineux.

---

## 🔧 Paramètres Ajustables

### Intensité du flou

**Fichier :** `app/globals.css` (ligne ~85)

```css
backdrop-filter: blur(20px); /* Valeur actuelle : 20px */
```

**Ajustements possibles :**

- `blur(10px)` → Flou léger
- `blur(20px)` → Flou moyen (actuel)
- `blur(30px)` → Flou fort
- `blur(40px)` → Flou très fort

### Opacité de la teinte blanche

**Fichier :** `app/globals.css` (ligne ~88)

```css
background: rgba(255, 255, 255, 0.2); /* 0.2 = 20% d'opacité */
```

**Ajustements possibles :**

- `0.1` → Logo plus transparent
- `0.2` → Opacité actuelle
- `0.3` → Logo plus blanc/lumineux
- `0.4` → Logo très blanc

### Bordure lumineuse

**Fichier :** `app/globals.css` (ligne ~100)

```css
border: 2px solid rgba(255, 255, 255, 0.5);
```

**Ajustements possibles :**

- Épaisseur : `1px`, `2px`, `3px`
- Opacité : `0.3` (discret), `0.5` (actuel), `0.7` (prononcé)

### Ombre portée

**Fichier :** `app/globals.css` (lignes ~104-107)

```css
box-shadow:
  0 25px 70px rgba(0, 169, 206, 0.4),
  /* Ombre turquoise */ 0 10px 20px rgba(0, 0, 0, 0.3),
  /* Ombre noire */ inset 0 2px 0 rgba(255, 255, 255, 0.4); /* Reflet interne */
```

---

## 🎯 Effet 3D au Survol

**Fichier :** `app/(site)/page.tsx` (lignes ~181-184)

```tsx
animate={{
  rotateX: mousePos.y * 10,   // Rotation sur l'axe X
  rotateY: mousePos.x * -10,  // Rotation sur l'axe Y
}}
```

**Ajustements possibles :**

- Multiplier par `5` → Effet 3D subtil
- Multiplier par `10` → Effet 3D actuel
- Multiplier par `15` → Effet 3D prononcé

---

## 💡 Reflet Lumineux Interactif

**Fichier :** `app/(site)/page.tsx` (lignes ~193-207)

Un gradient radial blanc suit la position de la souris pour créer un reflet lumineux dynamique.

```tsx
background: `radial-gradient(
  circle at ${50 + mousePos.x * 50}% ${50 + mousePos.y * 50}%, 
  rgba(255,255,255,0.3) 0%, 
  transparent 70%
)`;
```

**Ajustements possibles :**

- `0.2` → Reflet discret
- `0.3` → Reflet actuel
- `0.5` → Reflet prononcé

---

## 📁 Fichiers Concernés

1. **`app/globals.css`** (lignes 59-155)
   - Définition de la classe `.hero-logo-glass`
   - Tous les styles CSS de l'effet

2. **`app/(site)/page.tsx`** (lignes 22-30, 156-218)
   - Gestion du mouvement de la souris
   - Effet 3D tilt
   - Reflet lumineux dynamique

3. **`public/images/LogoCNC_W.svg`**
   - Le fichier SVG du logo utilisé comme masque

---

## 🚀 Pour Tester les Modifications

1. Modifiez les valeurs dans `globals.css`
2. Sauvegardez le fichier
3. Le navigateur se rafraîchit automatiquement (hot reload)
4. Testez l'effet en survolant le logo avec la souris

---

## ⚠️ Notes Importantes

- **Compatibilité navigateur :** L'effet `backdrop-filter` fonctionne sur tous les navigateurs modernes (Chrome, Firefox, Safari, Edge)
- **Performance :** L'effet utilise l'accélération GPU (`transform: translateZ(0)`) pour des performances optimales
- **Responsive :** L'effet s'adapte automatiquement aux différentes tailles d'écran

---

## 🎨 Exemples de Variations

### Variation 1 : Flou Intense

```css
backdrop-filter: blur(40px);
background: rgba(255, 255, 255, 0.15);
```

### Variation 2 : Logo Très Lumineux

```css
backdrop-filter: blur(20px);
background: rgba(255, 255, 255, 0.4);
border: 3px solid rgba(255, 255, 255, 0.7);
```

### Variation 3 : Effet Discret

```css
backdrop-filter: blur(10px);
background: rgba(255, 255, 255, 0.1);
border: 1px solid rgba(255, 255, 255, 0.3);
```

---

**Dernière mise à jour :** 29 janvier 2026
